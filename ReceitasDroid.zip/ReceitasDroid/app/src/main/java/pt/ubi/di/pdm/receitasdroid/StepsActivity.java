package pt.ubi.di.pdm.receitasdroid;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class StepsActivity extends AppCompatActivity {
    private SQLiteDatabase oSQLiteDB;
    private AjudanteParaAbrirBD oAPABD;
    private int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_steps);
        Intent intent = getIntent();
        id = intent.getIntExtra("id", -1);

        oAPABD = new AjudanteParaAbrirBD(this);
        oSQLiteDB = oAPABD.getWritableDatabase();

        TextView oLL = (TextView) findViewById(R.id.Steps);
        Cursor oCursor = oSQLiteDB.query(oAPABD.TABLE_STEPS, new String[]{ "step" }, "id_rec="+id ,
                null , null , null , null , null);

        oCursor.moveToFirst();
        //TextView t3 = (TextView) getLayoutInflater().inflate(R.layout.steps, null);

        //Button don = oLL.findViewById(R.id.done);
        //don.setId(oCursor.getInt(0)*10+1);

        //oCursor = oSQLiteDB.query(oAPABD.TABLE_STEPS,new String[]{"step"},"id_rec="+id,null,null,null,null,null);

        oLL.setText(oCursor.getString(0));
//        boolean bCarryOn=oCursor.moveToNext();
//
//        while (bCarryOn) {
//            t3.setText(oCursor.getString(0));
//            Button d = oLL.findViewById(R.id.done);
//            d.setId(oCursor.getInt(0)*10+1);
//            Button b = oLL.findViewById(R.id.back);
//            b.setId(oCursor.getInt(0)*10+1);
//
//            oLL.setText(t3.getText().toString());
//            bCarryOn = oCursor.moveToNext();
//        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        oSQLiteDB = oAPABD.getWritableDatabase();
    }

    @Override
    protected void onPause() {
        super.onPause();
        oAPABD.close();
    }
    public void back(View view) {
        Intent intent = new Intent( this, StepsActivity.class);
        intent.putExtra("id", id);
        startActivity(intent);
    }
    public void done(View view) {
        Intent intent = new Intent( this, StepsActivity.class);
        intent.putExtra("id", id);
        startActivity(intent);
    }
}
