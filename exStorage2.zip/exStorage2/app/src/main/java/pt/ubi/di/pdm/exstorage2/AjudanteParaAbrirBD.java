package pt.ubi.di.pdm.exstorage2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class AjudanteParaAbrirBD extends SQLiteOpenHelper {
    private static final int DB_VERSION=1;
    private static final String BD_NAME="FavoriteMovies";
    protected static final String TABLE_NAME="Movie";
    protected static final String COL1="id";
    protected static final String COL2="Name";
    protected static final String COL3="year";

    private static final String CREATE_MOVIE="Create Table Movie(" +
            "id int primary key," +
            "name varchar(50)," +
            "year int)";

    public AjudanteParaAbrirBD(Context context){
        super(context,BD_NAME,null,DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL(CREATE_MOVIE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE"+TABLE_NAME+ ";");
        db.execSQL(CREATE_MOVIE);
    }

}
